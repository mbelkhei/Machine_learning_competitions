# kaggle
This repository is a collection of Kaggle competitions 
